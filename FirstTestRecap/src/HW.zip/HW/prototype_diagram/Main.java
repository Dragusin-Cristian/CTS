package HW.prototype_diagram;

public class Main {
    public static void main(String[] args) {

    }
}
