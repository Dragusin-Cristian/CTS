package HW.ex1.cts.cristian.dragusin.g1032.singleton;

public interface ITesingModule {
    public String test();
}
